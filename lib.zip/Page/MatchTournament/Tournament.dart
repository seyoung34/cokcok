import 'package:flutter/material.dart';
import 'package:flutter_tournament_bracket/flutter_tournament_bracket.dart';

class Team {
  final String id;
  Team(this.id);
}

class TournamentFromTeams extends StatelessWidget {
  final List<Team> teams;

  const TournamentFromTeams({super.key, required this.teams});

  @override
  Widget build(BuildContext context) {
    final tournamentList = generateTournamentList(teams);

    return Scaffold(
      appBar: AppBar(title: const Text('토너먼트 대진표')),
      body: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: TournamentBracket(
          list: tournamentList,
          card: (item) => customMatchCard(item),
          itemsMarginVertical: 20.0,
          cardWidth: 220.0,
          cardHeight: 100,
          lineWidth: 80,
          lineThickness: 4,
          lineBorderRadius: 12,
          lineColor: Colors.green,
        ),
      ),
    );
  }

  List<Tournament> generateTournamentList(List<Team> teams) {
    final shuffledTeams = [...teams];
    shuffledTeams.shuffle();

    int teamCount = shuffledTeams.length;
    int nextPowerOfTwo = 1;
    while (nextPowerOfTwo < teamCount) {
      nextPowerOfTwo *= 2;
    }

    int byes = nextPowerOfTwo - teamCount;
    List<TournamentMatch> firstRound = [];

    final List<String> teamNames = shuffledTeams.map((t) => t.id).toList();

    while (teamNames.length >= 2) {
      String a = teamNames.removeAt(0);
      String b = teamNames.removeAt(0);
      firstRound.add(TournamentMatch(id: "", teamA: a, teamB: b));
    }

    if (teamNames.isNotEmpty) {
      firstRound.add(TournamentMatch(id: "", teamA: teamNames.removeAt(0), teamB: "부전승", scoreTeamA: "승", scoreTeamB: ""));
    }

    return [Tournament(matches: firstRound)];
  }

  Widget customMatchCard(TournamentMatch item) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.blue[100],
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.teamA ?? "-", style: const TextStyle(fontSize: 16)),
                const SizedBox(height: 8),
                Text(item.teamB ?? "-", style: const TextStyle(fontSize: 16)),
              ],
            ),
          ),
          const VerticalDivider(),
          Column(
            children: [
              Text(item.scoreTeamA ?? "", style: const TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              Text(item.scoreTeamB ?? "", style: const TextStyle(fontWeight: FontWeight.bold)),
            ],
          )
        ],
      ),
    );
  }
}
